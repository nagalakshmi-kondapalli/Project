/* Write a Program to take a 2 digit number and calculate sum of digits. */
var a = Number(prompt("Enter first number"));
document.write("value a="+a)
document.write("<br>");
var b = Number(prompt("Enter second number"));
document.write("value b="+b)
document.write("<br>");
document.write("The sum of two digit numbers are :" +(a + b)); 
