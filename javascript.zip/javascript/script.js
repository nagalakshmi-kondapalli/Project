/* Write a Program to swap 2 numbers without using third variable */

/*This values are before swapping our original values */

a = 10;
b = 20;
document.write("our original values:");
document.write("<br>");
document.write("a:" +a);
document.write("<br>");
document.write("b:" +b);
document.write("<br>");
a = a+b; /* here our value will be a= 30 */
b = a-b; /* here our value will be b=10 */   /* our values will be swapped */
a = a-b; /* here our value will  be a = 20 */ 
document.write("After swapping values:" );
document.write("<br>");
document.write("a:" +a);
document.write("<br>");
document.write("b:" +b);
document.write("<br>");
document.write("<br>");
document.write("<br>");
