/*Write a Program to take a temperature in Celsius and convert into Fahrenheit.*/
// Convert the temperature from Celsius to Fahrenheit using the conversion formula: Fahrenheit = (Celsius * 9/5) + 32.
document.write("Celsius Temperature: ");
c1=prompt("Enter Celsius Temperature");
document.write(+c1);
fahrenheit = (c1 * 9/5) + 32;
document.write("<br>");
document.write("Fahrenheit Temperature:"+fahrenheit);

document.write("<br>");
document.write("<br>");
document.write("<br>");