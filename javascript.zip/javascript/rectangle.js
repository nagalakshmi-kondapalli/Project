// Write a Program to calculate area of rectangle.

document.write("Enter dimensions of rectangle:");
document.write("<br>");
length=prompt("Enter height of the rectangle:");
document.write("length of rectangle is: " +length);
document.write("<br>");
breadth = prompt("Enter width of the rectangle:");
document.write("breadth of the rectangle: "+breadth);
area=length*breadth;
document.write("<br>");
document.write("Area of Rectangle :"+area);
document.write("<br>");
document.write("<br>");
document.write("<br>");